from db import get_tmdb_meta
from datetime import datetime
import base64
from io import BytesIO

import matplotlib.pyplot as plt

date1 = "2022-10-15"
date2 = "2022-10-16"
filter2 = "1"

start = str(date1).split("-")
end = str(date2).split("-")
s1, s2, s3 = int(start[0]), int(start[1]), int(start[2])
e1, e2, e3 = int(end[0]), int(end[1]), int(end[2])
if date1 == date2:
    e3 += 1
date_filter = {"timestamp": {"$gte": datetime(s1, s2, s3),
                             "$lt": datetime(e1, e2, e3)}}
if filter2 == "1":
    data = {}
    res = get_tmdb_meta().find(date_filter).sort("rating", -1).limit(10)
    res_list = []
    for r in res:
        title = r["title"]
        rating = r["rating"]
        data[title] = rating

    print(data)
    title = list('\n'.join(' '.join(s) for s in zip(*[iter(label.split())] * 2)) for label in data.keys())
    tweets = list(data.values())

    fig = plt.figure(figsize=(10, 5))
    plt.xticks(rotation=45, ha='right')
    plt.ylabel("Rating", rotation=90)
    plt.bar(title, tweets, color='blue',
            width=0.5)

    plt.title('Top-ten movies')
    plt.tight_layout()
    img = BytesIO()
    plt.savefig(img, format='png', bbox_inches='tight')
    plt.show()
    plt.close()
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode('utf8')
    print(plot_url)
