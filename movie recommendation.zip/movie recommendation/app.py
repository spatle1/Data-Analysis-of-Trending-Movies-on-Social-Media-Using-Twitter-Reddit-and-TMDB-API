from flask import Flask, render_template, request

app = Flask(__name__)
from plot_movies import collect_data
import matplotlib

matplotlib.use('Agg')


@app.route('/')
def hello_world():
    return render_template('homepage.html')


@app.route("/plot_movies", methods=['POST'])
def plot_movies_by_date():
    date1 = request.form['date_1']
    date2 = request.form['date_2']
    type = request.form['movie_filter']
    this_year = "disable"
    if '2022_flag' in request.form:
        this_year = request.form['2022_flag']
    plot_url = collect_data(date1, date2, type, this_year)
    return render_template('plot_image.html', plot_url=plot_url)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
